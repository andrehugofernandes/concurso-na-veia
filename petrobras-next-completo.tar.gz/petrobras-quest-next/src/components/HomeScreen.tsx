import { Usuario, TipoSimulado } from '@/lib/types';
import { formatarTempo } from '@/lib/utils';

interface Props {
  usuario: Usuario;
  setUsuario: (usuario: Usuario) => void;
  iniciarSimulado: (tipo: TipoSimulado, quantidade: number) => void;
  gerandoQuestoes: boolean;
}

export default function HomeScreen({ usuario, setUsuario, iniciarSimulado, gerandoQuestoes }: Props) {
  if (!usuario.nome) {
    return (
      <div className="min-h-screen gradient-bg flex items-center justify-center p-4">
        <div className="bg-white rounded-xl shadow-2xl p-8 max-w-md w-full">
          <h1 className="text-3xl font-bold text-center mb-6">🤖 Petrobras Quest AI</h1>
          <p className="text-gray-600 text-center mb-6">Digite seu nome para começar:</p>
          <input
            type="text"
            className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
            placeholder="Seu nome"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && e.currentTarget.value) {
                setUsuario({ ...usuario, nome: e.currentTarget.value });
              }
            }}
            autoFocus
          />
        </div>
      </div>
    );
  }

  const taxaAcerto = usuario.questoesCertas + usuario.questoesErradas > 0 
    ? Math.round((usuario.questoesCertas / (usuario.questoesCertas + usuario.questoesErradas)) * 100)
    : 0;

  return (
    <div className="min-h-screen gradient-bg">
      <div className="bg-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Petrobras Quest AI</h1>
              <p className="text-gray-600">Questões Ilimitadas com IA</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-800">{usuario.nome}</p>
              <p className="text-purple-600 font-semibold">{usuario.nivel}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <p className="text-gray-600 text-sm">XP Total</p>
            <p className="text-3xl font-bold text-purple-600">{usuario.xp}</p>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <p className="text-gray-600 text-sm">Taxa</p>
            <p className="text-3xl font-bold text-green-600">{taxaAcerto}%</p>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <p className="text-gray-600 text-sm">Sequência</p>
            <p className="text-3xl font-bold text-orange-600">{usuario.sequenciaAtual}</p>
          </div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <p className="text-gray-600 text-sm">Conquistas</p>
            <p className="text-3xl font-bold text-yellow-600">{usuario.conquistas.length}</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl shadow-lg p-6 text-white">
            <p className="text-purple-100 text-sm">IA Geradas</p>
            <p className="text-3xl font-bold">{usuario.questoesGeradas}</p>
          </div>
        </div>

        {/* Destaque IA */}
        <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-xl shadow-2xl p-6 mb-8 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold mb-1">🤖 Powered by Claude AI</h3>
              <p className="text-purple-100">Questões geradas com IA no estilo CESGRANRIO</p>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg px-4 py-2">
              <p className="text-sm">Dificuldade Adaptativa ✓</p>
            </div>
          </div>
        </div>

        {/* Simulados */}
        <h2 className="text-3xl font-bold text-white mb-6 neon-text">⚡ Simulados Rápidos (5 questões)</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {[
            { tipo: 'portugues', nome: 'Português', cor: 'blue', icon: '📚' },
            { tipo: 'matematica', nome: 'Matemática', cor: 'red', icon: '🔢' },
            { tipo: 'operacao', nome: 'Operação', cor: 'green', icon: '🏭' }
          ].map(({ tipo, nome, cor, icon }) => (
            <div key={tipo} className="bg-white rounded-xl shadow-lg overflow-hidden card-hover">
              <div className={`bg-gradient-to-r from-${cor}-500 to-${cor}-600 p-6 text-white`}>
                <div className="text-4xl mb-2">{icon}</div>
                <h3 className="text-2xl font-bold">{nome}</h3>
                <p className="opacity-90">5 questões IA</p>
              </div>
              <div className="p-6">
                <button
                  onClick={() => iniciarSimulado(tipo as TipoSimulado, 5)}
                  disabled={gerandoQuestoes}
                  className={`w-full bg-${cor}-600 hover:bg-${cor}-700 text-white py-3 rounded-lg font-semibold transition disabled:opacity-50`}
                >
                  Gerar Simulado
                </button>
              </div>
            </div>
          ))}
        </div>

        <h2 className="text-3xl font-bold text-white mb-6 neon-text">🔥 Simulados Intensivos</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden border-4 border-purple-400">
            <div className="bg-gradient-to-r from-purple-500 to-purple-600 p-6 text-white">
              <div className="text-4xl mb-2">🚀</div>
              <h3 className="text-2xl font-bold">Maratona 20 Questões</h3>
            </div>
            <div className="p-6">
              <button
                onClick={() => iniciarSimulado('completo', 20)}
                disabled={gerandoQuestoes}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg font-semibold transition disabled:opacity-50"
              >
                Gerar 20 Questões! 🚀
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg overflow-hidden border-4 border-yellow-400">
            <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-6 text-white">
              <div className="text-4xl mb-2">🔥</div>
              <h3 className="text-2xl font-bold">Desafio 50 Questões</h3>
            </div>
            <div className="p-6">
              <button
                onClick={() => iniciarSimulado('completo', 50)}
                disabled={gerandoQuestoes}
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white py-3 rounded-lg font-semibold transition disabled:opacity-50"
              >
                Aceitar Desafio! 💪
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
