import { NextRequest, NextResponse } from 'next/server';

const promptsMateria: Record<string, string> = {
  portugues: `Você é um especialista em criar questões de concurso no estilo CESGRANRIO para a Petrobras.

INSTRUÇÕES CRÍTICAS:
1. Crie UMA questão de Língua Portuguesa para concurso Petrobras nível médio
2. Estilo CESGRANRIO: enunciado CURTO (2-3 linhas), objetivo, direto
3. 5 alternativas plausíveis
4. Foco em: interpretação, gramática aplicada, concordância, regência, crase
5. Contextualize com temas da indústria (petróleo, energia, sustentabilidade) quando possível
6. Evite textos longos - a CESGRANRIO prefere questões concisas

Retorne APENAS um JSON válido (sem markdown, sem explicações extras):
{
  "enunciado": "texto da questão",
  "alternativas": ["opção A", "opção B", "opção C", "opção D", "opção E"],
  "correta": 0,
  "explicacao": "explicação pedagógica detalhada",
  "assunto": "nome do assunto específico",
  "dificuldade": "Fácil|Média|Difícil"
}`,

  matematica: `Você é um especialista em criar questões de concurso no estilo CESGRANRIO para a Petrobras.

INSTRUÇÕES CRÍTICAS:
1. Crie UMA questão de Matemática para concurso Petrobras nível médio
2. Estilo CESGRANRIO: problema prático, aplicado, DIRETO
3. Números que facilitam cálculo mental (evite cálculos complexos)
4. 5 alternativas com valores próximos (teste atenção do candidato)
5. Foco em: porcentagem, regra de três, razão/proporção, juros simples, geometria básica
6. Contextualize com situações da indústria (produção, volumes, custos, etc)

Retorne APENAS um JSON válido (sem markdown):
{
  "enunciado": "texto do problema",
  "alternativas": ["valor 1", "valor 2", "valor 3", "valor 4", "valor 5"],
  "correta": 0,
  "explicacao": "resolução passo a passo detalhada",
  "assunto": "nome do assunto específico",
  "dificuldade": "Fácil|Média|Difícil"
}`,

  operacao: `Você é um especialista em criar questões de concurso no estilo CESGRANRIO para a Petrobras.

INSTRUÇÕES CRÍTICAS:
1. Crie UMA questão de Conhecimentos Específicos para TÉCNICO DE OPERAÇÃO
2. Estilo CESGRANRIO: prático, aplicado, situacional
3. Temas: processos de refino, segurança operacional, instrumentação, química do petróleo, física aplicada, SMS
4. 5 alternativas objetivas
5. Contexto: plataformas, refinarias, operações reais

Retorne APENAS um JSON válido (sem markdown):
{
  "enunciado": "situação ou pergunta técnica",
  "alternativas": ["opção A", "opção B", "opção C", "opção D", "opção E"],
  "correta": 0,
  "explicacao": "explicação técnica detalhada",
  "assunto": "nome do assunto específico",
  "dificuldade": "Fácil|Média|Difícil"
}`,

  administracao: `Você é um especialista em criar questões de concurso no estilo CESGRANRIO para a Petrobras.

INSTRUÇÕES CRÍTICAS:
1. Crie UMA questão de Conhecimentos Específicos para área ADMINISTRATIVA/LOGÍSTICA
2. Estilo CESGRANRIO: conceitual mas aplicado
3. Temas: gestão de estoques, logística, licitações (Lei 13.303/16), administração geral, contabilidade básica
4. 5 alternativas claras
5. Contexto: situações empresariais reais

Retorne APENAS um JSON válido (sem markdown):
{
  "enunciado": "situação ou pergunta",
  "alternativas": ["opção A", "opção B", "opção C", "opção D", "opção E"],
  "correta": 0,
  "explicacao": "explicação detalhada com conceitos",
  "assunto": "nome do assunto específico",
  "dificuldade": "Fácil|Média|Difícil"
}`,

  seguranca: `Você é um especialista em criar questões de concurso no estilo CESGRANRIO para a Petrobras.

INSTRUÇÕES CRÍTICAS:
1. Crie UMA questão de SEGURANÇA DO TRABALHO
2. Estilo CESGRANRIO: prático, normas aplicadas
3. Temas: NRs (especialmente NR-10, NR-12, NR-35), EPIs, prevenção de acidentes, análise de riscos
4. 5 alternativas objetivas
5. Contexto: indústria petrolífera e situações reais

Retorne APENAS um JSON válido (sem markdown):
{
  "enunciado": "situação ou pergunta sobre segurança",
  "alternativas": ["opção A", "opção B", "opção C", "opção D", "opção E"],
  "correta": 0,
  "explicacao": "explicação com base nas normas",
  "assunto": "nome do assunto específico",
  "dificuldade": "Fácil|Média|Difícil"
}`
};

export async function POST(request: NextRequest) {
  try {
    const { materia, dificuldade } = await request.json();

    const prompt = promptsMateria[materia];
    if (!prompt) {
      return NextResponse.json(
        { error: 'Matéria não encontrada' },
        { status: 400 }
      );
    }

    const promptComDificuldade = dificuldade 
      ? prompt.replace('Retorne APENAS', `Gere uma questão de dificuldade ${dificuldade}. Retorne APENAS`)
      : prompt;

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        messages: [
          { 
            role: 'user', 
            content: promptComDificuldade
          }
        ]
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Erro na API Anthropic:', errorText);
      return NextResponse.json(
        { error: `Erro na API: ${response.status}` },
        { status: response.status }
      );
    }

    const data = await response.json();
    const textoResposta = data.content[0].text;
    
    // Extrair JSON do texto
    let jsonTexto = textoResposta;
    if (textoResposta.includes('```json')) {
      jsonTexto = textoResposta.split('```json')[1].split('```')[0].trim();
    } else if (textoResposta.includes('```')) {
      jsonTexto = textoResposta.split('```')[1].split('```')[0].trim();
    }
    
    const questao = JSON.parse(jsonTexto);
    
    // Adicionar metadados
    questao.materia = materia.charAt(0).toUpperCase() + materia.slice(1);
    questao.banca = 'CESGRANRIO';
    questao.geradaPorIA = true;
    questao.id = Date.now() + Math.random();
    
    return NextResponse.json(questao);
  } catch (error: any) {
    console.error('Erro ao gerar questão:', error);
    return NextResponse.json(
      { error: error.message || 'Erro ao gerar questão' },
      { status: 500 }
    );
  }
}
