'use client';

import { useState, useEffect } from 'react';
import { Usuario, Questao, Simulado, TipoSimulado } from '@/lib/types';
import { calcularNivel, formatarTempo, salvarUsuario, carregarUsuario } from '@/lib/utils';
import HomeScreen from '@/components/HomeScreen';
import LoadingScreen from '@/components/LoadingScreen';
import SimuladoScreen from '@/components/SimuladoScreen';
import ResultadoScreen from '@/components/ResultadoScreen';

const usuarioInicial: Usuario = {
  nome: '',
  xp: 0,
  nivel: 'Estagiário',
  questoesCertas: 0,
  questoesErradas: 0,
  sequenciaAtual: 0,
  maiorSequencia: 0,
  conquistas: [],
  historico: [],
  questoesGeradas: 0,
};

export default function Home() {
  const [tela, setTela] = useState<'home' | 'gerando' | 'simulado' | 'resultado'>('home');
  const [usuario, setUsuario] = useState<Usuario>(usuarioInicial);
  const [simuladoAtual, setSimuladoAtual] = useState<Simulado | null>(null);
  const [questaoAtual, setQuestaoAtual] = useState(0);
  const [respostaSelecionada, setRespostaSelecionada] = useState<number | null>(null);
  const [mostrarResultado, setMostrarResultado] = useState(false);
  const [cronometro, setCronometro] = useState(0);
  const [cronometroAtivo, setCronometroAtivo] = useState(false);
  const [gerandoQuestoes, setGerandoQuestoes] = useState(false);

  // Carregar dados
  useEffect(() => {
    const dadosSalvos = carregarUsuario();
    if (dadosSalvos) {
      setUsuario(dadosSalvos);
    }
  }, []);

  // Salvar dados
  useEffect(() => {
    if (usuario.nome) {
      salvarUsuario(usuario);
    }
  }, [usuario]);

  // Cronômetro
  useEffect(() => {
    let intervalo: NodeJS.Timeout;
    if (cronometroAtivo) {
      intervalo = setInterval(() => {
        setCronometro(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(intervalo);
  }, [cronometroAtivo]);

  const gerarQuestaoIA = async (materia: string, dificuldade?: string): Promise<Questao> => {
    const response = await fetch('/api/gerar-questao', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ materia, dificuldade }),
    });

    if (!response.ok) {
      throw new Error('Erro ao gerar questão');
    }

    return await response.json();
  };

  const gerarQuestoes = async (tipo: TipoSimulado, quantidade: number): Promise<Questao[]> => {
    const questoes: Questao[] = [];
    const materias: Record<string, string[]> = {
      'portugues': ['portugues'],
      'matematica': ['matematica'],
      'operacao': ['operacao'],
      'administracao': ['administracao'],
      'seguranca': ['seguranca'],
      'completo': ['portugues', 'matematica', 'operacao', 'administracao']
    };

    const materiasEscolhidas = materias[tipo] || ['portugues'];
    const questoesPorMateria = Math.ceil(quantidade / materiasEscolhidas.length);

    for (const materia of materiasEscolhidas) {
      for (let i = 0; i < questoesPorMateria && questoes.length < quantidade; i++) {
        try {
          let dificuldade = undefined;
          const taxaAcerto = usuario.questoesCertas / (usuario.questoesCertas + usuario.questoesErradas || 1);
          if (taxaAcerto > 0.8) dificuldade = 'Difícil';
          else if (taxaAcerto > 0.6) dificuldade = 'Média';
          else if (taxaAcerto < 0.5) dificuldade = 'Fácil';

          const questao = await gerarQuestaoIA(materia, dificuldade);
          questoes.push(questao);
        } catch (error) {
          console.error(`Erro ao gerar questão ${i + 1}:`, error);
        }
      }
    }

    return questoes;
  };

  const iniciarSimulado = async (tipo: TipoSimulado, quantidade: number = 5) => {
    setGerandoQuestoes(true);
    setTela('gerando');

    try {
      const questoes = await gerarQuestoes(tipo, quantidade);
      
      if (questoes.length === 0) {
        throw new Error('Nenhuma questão foi gerada');
      }

      setSimuladoAtual({
        tipo,
        questoes,
        respostas: new Array(questoes.length).fill(null),
        iniciado: Date.now()
      });

      setUsuario(prev => ({
        ...prev,
        questoesGeradas: prev.questoesGeradas + questoes.length
      }));

      setQuestaoAtual(0);
      setRespostaSelecionada(null);
      setMostrarResultado(false);
      setCronometro(0);
      setCronometroAtivo(true);
      setGerandoQuestoes(false);
      setTela('simulado');
    } catch (error: any) {
      console.error('Erro ao iniciar simulado:', error);
      setGerandoQuestoes(false);
      setTela('home');
      alert(`Erro ao gerar questões: ${error.message}\n\nTente novamente em alguns segundos.`);
    }
  };

  const responderQuestao = (indiceResposta: number) => {
    if (mostrarResultado) return;
    setRespostaSelecionada(indiceResposta);
  };

  const confirmarResposta = () => {
    if (respostaSelecionada === null || !simuladoAtual) return;

    const questao = simuladoAtual.questoes[questaoAtual];
    const acertou = respostaSelecionada === questao.correta;

    const novasRespostas = [...simuladoAtual.respostas];
    novasRespostas[questaoAtual] = {
      selecionada: respostaSelecionada,
      correta: acertou
    };

    setSimuladoAtual({
      ...simuladoAtual,
      respostas: novasRespostas
    });

    let novoXP = usuario.xp;
    let novaSequencia = usuario.sequenciaAtual;
    let novasConquistas = [...usuario.conquistas];

    if (acertou) {
      novoXP += 10;
      novaSequencia += 1;

      if (novaSequencia === 10 && !novasConquistas.includes('combo10')) {
        novoXP += 50;
        novasConquistas.push('combo10');
        setTimeout(() => alert('🎉 COMBO! +50 XP por 10 acertos seguidos!'), 500);
      }

      if (novaSequencia === 20 && !novasConquistas.includes('combo20')) {
        novoXP += 100;
        novasConquistas.push('combo20');
        setTimeout(() => alert('🔥 COMBO INSANO! +100 XP por 20 acertos seguidos!'), 500);
      }

      setUsuario({
        ...usuario,
        xp: novoXP,
        questoesCertas: usuario.questoesCertas + 1,
        sequenciaAtual: novaSequencia,
        maiorSequencia: Math.max(novaSequencia, usuario.maiorSequencia),
        nivel: calcularNivel(novoXP),
        conquistas: novasConquistas
      });
    } else {
      if (novaSequencia > 0) {
        novoXP = Math.max(0, novoXP - 20);
      }
      novaSequencia = 0;

      setUsuario({
        ...usuario,
        xp: novoXP,
        questoesErradas: usuario.questoesErradas + 1,
        sequenciaAtual: 0,
        nivel: calcularNivel(novoXP)
      });
    }

    setMostrarResultado(true);
  };

  const proximaQuestao = () => {
    if (!simuladoAtual) return;

    if (questaoAtual < simuladoAtual.questoes.length - 1) {
      setQuestaoAtual(questaoAtual + 1);
      setRespostaSelecionada(null);
      setMostrarResultado(false);
    } else {
      finalizarSimulado();
    }
  };

  const finalizarSimulado = () => {
    if (!simuladoAtual) return;

    setCronometroAtivo(false);

    const totalAcertos = simuladoAtual.respostas.filter(r => r && r.correta).length;
    const totalQuestoes = simuladoAtual.questoes.length;
    const percentual = Math.round((totalAcertos / totalQuestoes) * 100);

    let bonusXP = 200;
    if (percentual >= 90) bonusXP += 100;
    else if (percentual >= 80) bonusXP += 50;

    const novoHistorico = [...usuario.historico, {
      data: new Date().toISOString(),
      tipo: simuladoAtual.tipo,
      acertos: totalAcertos,
      total: totalQuestoes,
      percentual,
      tempo: cronometro
    }];

    let novasConquistas = [...usuario.conquistas];
    if (percentual >= 90 && !novasConquistas.includes('perfeccionista')) {
      novasConquistas.push('perfeccionista');
    }
    if (usuario.historico.length + 1 >= 10 && !novasConquistas.includes('maratonista')) {
      novasConquistas.push('maratonista');
    }

    setUsuario({
      ...usuario,
      xp: usuario.xp + bonusXP,
      historico: novoHistorico,
      conquistas: novasConquistas
    });

    setTela('resultado');
  };

  const voltarHome = () => {
    setTela('home');
    setSimuladoAtual(null);
    setQuestaoAtual(0);
    setCronometro(0);
    setCronometroAtivo(false);
  };

  if (tela === 'gerando') {
    return <LoadingScreen />;
  }

  if (tela === 'home') {
    return (
      <HomeScreen
        usuario={usuario}
        setUsuario={setUsuario}
        iniciarSimulado={iniciarSimulado}
        gerandoQuestoes={gerandoQuestoes}
      />
    );
  }

  if (tela === 'simulado' && simuladoAtual) {
    return (
      <SimuladoScreen
        simulado={simuladoAtual}
        questaoAtual={questaoAtual}
        respostaSelecionada={respostaSelecionada}
        mostrarResultado={mostrarResultado}
        cronometro={cronometro}
        usuario={usuario}
        responderQuestao={responderQuestao}
        confirmarResposta={confirmarResposta}
        proximaQuestao={proximaQuestao}
        voltarHome={voltarHome}
      />
    );
  }

  if (tela === 'resultado' && simuladoAtual) {
    return (
      <ResultadoScreen
        simulado={simuladoAtual}
        cronometro={cronometro}
        usuario={usuario}
        voltarHome={voltarHome}
        iniciarSimulado={iniciarSimulado}
      />
    );
  }

  return null;
}
