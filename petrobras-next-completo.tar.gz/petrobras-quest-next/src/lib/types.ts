export interface Usuario {
  nome: string;
  xp: number;
  nivel: string;
  questoesCertas: number;
  questoesErradas: number;
  sequenciaAtual: number;
  maiorSequencia: number;
  conquistas: string[];
  historico: HistoricoSimulado[];
  questoesGeradas: number;
}

export interface HistoricoSimulado {
  data: string;
  tipo: string;
  acertos: number;
  total: number;
  percentual: number;
  tempo: number;
}

export interface Questao {
  id: number | string;
  materia: string;
  assunto: string;
  enunciado: string;
  alternativas: string[];
  correta: number;
  explicacao: string;
  dificuldade: 'Fácil' | 'Média' | 'Difícil';
  banca: string;
  geradaPorIA?: boolean;
}

export interface Simulado {
  tipo: string;
  questoes: Questao[];
  respostas: (RespostaQuestao | null)[];
  iniciado: number;
}

export interface RespostaQuestao {
  selecionada: number;
  correta: boolean;
}

export type TipoSimulado = 'portugues' | 'matematica' | 'operacao' | 'administracao' | 'seguranca' | 'completo';
export type DificuldadeQuestao = 'Fácil' | 'Média' | 'Difícil';
